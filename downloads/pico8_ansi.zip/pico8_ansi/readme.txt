+---------------------------------------------------+
|                                                   |
|    PICO-8 ASCII/ANSI EXPORTER & VIEWER            |
|                                                   |
+---------------------------------------------------+

Contains :

- Playscii PICO-8 charset, palette & exporter     
  by pespe - 2023

- Pico-8 ASCII/ANSI viewer 
  by #592C63 - 2026

Use at your own risks :-)

+---------------------------------------------------+
|   ___ _/_ ___ _/_                                 |
|  | . | -_| . | -_|                                |
|  |  _|___|  _|___|                                |
|  |_|     |_|            http://peek.poke.free.fr  |
|               https://demozoo.org/sceners/123351  |
|                                                   |
|    Don't give up, be righteous, stay ATARI !      |
+---------------------------------------------------+
EOF
